package org.example.test;

import org.example.driver.BaseTest;
import org.example.page.HomePage;
import org.example.page.LoginPage;
import org.example.page.ProductPage;
import org.junit.Test;

public class GenelTest extends BaseTest {

    @Test
    public void genelTest()
    {
        HomePage homePage= new HomePage();

        homePage.home();

        LoginPage loginPage = new LoginPage();

        loginPage.login();

        ProductPage productPage = new ProductPage();

        productPage.scrollAndSelect();
    }

}
