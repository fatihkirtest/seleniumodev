package org.example.page;

import org.example.driver.BaseTest;
import org.junit.Assert;
import org.example.methods.Methods;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class ProductPage extends BaseTest {

    Methods methods;
    Logger logger = LogManager.getLogger(ProductPage.class);

    public ProductPage() {
        methods = new Methods();
    }

    public void scrollAndSelect() {
        methods.sendKeys(By.id("search-input"), "oyuncak");
        methods.click(By.cssSelector(".common-sprite.button-search"));
        methods.waitBySeconds(3);
        System.out.println("Oyuncak araması yapıldı");
        methods.waitBySeconds(2);
        methods.scrollWithAction(By.id("product-133053"));
        System.out.println("7. scrolla inildi");
        methods.waitBySeconds(2);
        methods.click(By.xpath("//a[@onclick='addToFavorites(399518);' and @class='add-to-favorites']"));
        methods.waitBySeconds(2);
        methods.click(By.xpath("//a[@onclick='addToFavorites(596239);' and @class='add-to-favorites']"));
        methods.waitBySeconds(2);
        methods.click(By.xpath("//a[@onclick='addToFavorites(494426);' and @class='add-to-favorites']"));
        methods.waitBySeconds(2);
        methods.click(By.xpath("//a[@onclick='addToFavorites(494781);' and @class='add-to-favorites']"));
        methods.waitBySeconds(2);
        System.out.println("4 ürün favorilere eklendi");
        methods.click(By.cssSelector("img[title='kitapla buluşmanın en kolay yolu!']"));
        System.out.println("Ana sayfaya geri dönüldü");
        methods.waitBySeconds(2);
        methods.click(By.className("class=mn-strong common-sprite"));
        methods.waitBySeconds(2);
        methods.click(By.className("mn-icon icon-angleRight"));
        methods.waitBySeconds(2);
        System.out.println("Tüm kitaplar > Hobi'ye tıklanıldı");
        methods.click(By.cssSelector("src=\"https://img.kitapyurdu.com/v1/getImage/fn:11439039/wi:100/wh:true\""));
        methods.waitBySeconds(2);
        System.out.println("Rastgele ürün seçildi");
        methods.click(By.id("button-cart"));
        methods.waitBySeconds(2);
        System.out.println("Seçilen rastgele ürün sepete eklendi");
        methods.click(By.id("cart-items"));
        methods.waitBySeconds(2);
        System.out.println("Sepetime gidildi");
        methods.click(By.className("common-sprite"));
        methods.click(By.className("href=\"https://www.kitapyurdu.com/index.php?route=account/logout\""));
        methods.waitBySeconds(2);
        System.out.println("Logout olundu");





    }
}
